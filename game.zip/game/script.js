$(document).ready(function(){
var count=0;
$(".row1 div,.row2 div,.row3 div").click(function(){
  if(count%2==0)
  {
  $(this).append("<span style='font-size:80px;color:white;text-align:center;width:100%;display:inline-block;color:red;'>X</span>")
 
  count++
 }

 else{
	count++
$(this).append("<span style='font-size:80px;color:white;text-align:center;width:100%;display:inline-block;'>O</span>")
}
});
});